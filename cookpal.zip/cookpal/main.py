import tkinter, json, os, datetime, glob
from tkinter import ttk, messagebox, filedialog
from PIL import Image, ImageTk
from functools import partial

def load_data(file_name):
    with open(file_name, 'r') as file:
        data = json.load(file)
    return data

def save_data(data, file_name):
    with open(file_name, 'w') as file:
        json.dump(data, file, indent=4)
        
def user_page(regEvent):
    def user_home_page():
        def click1():
            mode1_button.config(relief=tkinter.SUNKEN)
            mode2_button.config(relief=tkinter.RAISED)
            mode3_button.config(relief=tkinter.RAISED)
            mode1()

        def click2():
            mode1_button.config(relief=tkinter.RAISED)
            mode2_button.config(relief=tkinter.SUNKEN)
            mode3_button.config(relief=tkinter.RAISED)
            mode2()

        def click3():
            mode1_button.config(relief=tkinter.RAISED)
            mode2_button.config(relief=tkinter.RAISED)
            mode3_button.config(relief=tkinter.SUNKEN)
            mode3()

        def click_recipe(item):
            recipe_window = tkinter.Toplevel()
            recipe_window.title("Recipe")
            recipe_window.grab_set() # to focus on this window and make another window unclickable
            recipe_window.state('zoomed')

            frame = tkinter.Frame(recipe_window, padx=40, pady=30)
            frame.pack(side='top', fill='both', expand=True)
            label_frame = tkinter.LabelFrame(frame, text='Recipe', font=('Arial', 30), height=150, padx=40, pady=30)
            label_frame.pack(side='top', fill='both', expand=True)
            canva = tkinter.Canvas(label_frame)
            canva.pack(side='top', fill='both', expand=True)

            scrollbar_label = ttk.Scrollbar(canva, command=canva.yview)
            scrollbar_label.pack(side='right', fill='y')
            canva.configure(yscrollcommand=scrollbar_label.set)
            canva.bind('<Configure>', lambda e: canva.configure(scrollregion = canva.bbox('all')))
            box = tkinter.Frame(canva)
            box.pack(side='top', fill='both')
            canva.create_window((0,0), window=box, anchor='nw')

            key = data_recipes[item]
            for key, value in key.items():
                recipe = (key.title()+":", value)
                recipe = str(recipe).replace(",","\n      ").replace("{","").replace("}","").replace("'","").replace("(","").replace(")","").replace("[","").replace("]","")
                if key=='ingredients':
                    label_ingredients = tkinter.Label(box, text="ingredients:".title(), justify="left", font=('Arial', 13))
                    label_ingredients.grid(sticky='w')
                    label_main = tkinter.Label(box, text="Main:".title(), justify="left", font=('Arial', 13))
                    label_main.grid(sticky='w')
                    for index in range(len(value['main'])):
                        frame = tkinter.Frame(box)
                        frame.grid(sticky='w')
                        shopping_list_button_label = tkinter.Label(frame, text=("       " + value['main'][index]['name'] + "    " + str(value['main'][index]['amount']) + " " + value['main'][index]['unit'] + "  "), justify="left", font=('Arial', 13))
                        shopping_list_button_label.grid(row=0, column=0, sticky='w')
                        shopping_list_button = tkinter.Button(frame, text='Add to shopping list', command=partial(shopping_list, value['main'][index]['name']))
                        shopping_list_button.grid(row=0, column=1, sticky='w')
                    if 'pre_made' in value:
                        label_pre_made = tkinter.Label(box, text="Pre-made:".title(), justify="left", font=('Arial', 13))
                        label_pre_made.grid(sticky='w')
                        for index in range(len(value['pre_made'])):
                            frame = tkinter.Frame(box)
                            frame.grid(sticky='w')
                            shopping_list_button_label = tkinter.Label(frame, text=("       " + value['pre_made'][index]['name'] + "    " + str(value['main'][index]['amount']) + " " + value['main'][index]['unit'] + "  "), justify="left", font=('Arial', 13))
                            shopping_list_button_label.grid(row=0, column=0, sticky='w')
                            shopping_list_button = tkinter.Button(frame, text='Add to shopping list', command=partial(shopping_list, value['pre_made'][index]['name']))
                            shopping_list_button.grid(row=0, column=1, sticky='w')
                elif key=='steps':
                    label_steps = tkinter.Label(box, text="steps:".title(), justify="left", font=('Arial', 13))
                    label_steps.grid(sticky='w')
                    for x in value:
                        x.replace("\n      ",",")
                        frame_steps = tkinter.Frame(box)
                        frame_steps.grid(sticky='w')
                        spacing = tkinter.Label(frame_steps, text="         ")
                        spacing.grid(sticky='w', row='1', column='0')
                        label_steps = tkinter.Label(frame_steps, text=(x), justify="left", font=('Arial', 13), wraplength=1300)
                        label_steps.grid(sticky='w', row='1', column='1')
                else:
                    label = tkinter.Label(box, text=recipe, justify="left", font=('Arial', 13))
                    label.grid(sticky='w')

        def shopping_list(item):
            data_shopping_list = data_users[user]["shoppingList"]
            if item in data_shopping_list:
                messagebox.showinfo("Message",f"{item.title()} is already in your shopping list.")
            else:
                data_shopping_list.append(item)
                save_data(data_accounts, 'accounts.json')
                messagebox.showinfo("Message",f"{item.title()} is added to your shopping list.")

        def submission_onclick(rid):
            messagebox.showinfo('Instruction', 'Capture an image that shows the dish you made and your face within the frame.')

            points = data_users[user]['points']
            streak = data_users[user]['streak']
            current_datetime = datetime.datetime.now()
            date_for_file = current_datetime.strftime("%Y%m%d%H%M%S")
            date_for_dict = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
            filename = user + '_' + date_for_file
            filepath = filedialog.askopenfilename(
                title="Select Image",
                filetypes=(("Image files", "*.jpg;*.jpeg;*.png"), ("All files", "*.*"))
            )

            # Cancelled
            if not filepath:
                return 
            
            # Make a copy to submissions folder
            with open(filepath, 'rb') as rf:
                with open(f"submissions\{filename}.jpg", 'wb') as wf:
                    for line in rf:
                        wf.write(line)

            # Checking streaks
            all_submissions = data_users[user]['submissions']["approved"] + data_users[user]['submissions']["pending"] + data_users[user]['submissions']["rejected"]
            # Check if empty submissions
            if not all_submissions:
                streak = 1
            else:
                latest_submission = max(all_submissions, key=lambda x: x["time"])
                latest_date = datetime.datetime.strptime(latest_submission['time'], "%Y-%m-%d %H:%M:%S").date()
                current_date = current_datetime.date()

                # Calculate date difference   
                date_diff = (current_date - latest_date).days
                # Next day
                if date_diff == 1:  
                    streak += 1
                    if streak % 7 == 0:
                        bonus = int(1+(streak*0.1))  
                        points += bonus 
                # Same day   
                elif date_diff < 1:
                    pass
                # Streak lost
                else:
                    streak = 1  

            submission = {
                "recipe_id" : rid,
                "time" : date_for_dict,
                "filename" : filename + '.jpg',
            }
            data_users[user]['submissions']['pending'].append(submission)

            data_users[user]['streak'] = streak   
            save_data(data_accounts,'accounts.json')
            messagebox.showinfo("Message","Image uploaded and saved successfully. Please check approvals in Submissions page")

        def favorite_onclick(rid, button):
            # Get user's Favorites
            favorites = data_users[user]['favorites']

            text = button.cget("text")
            if text == 'Add to Favorites':
                favorites.append(rid)
                button.config(text="Remove from Favorites")

            else:
                favorites.remove(rid)
                button.config(text="Add to Favorites")

            # Save to storage     
            save_data(data_accounts,'accounts.json')

        def search(e, recipe_frame, recipe_box, to_display, matched_d):
            search_result = []
            search_term = search_bar.get().lower()
            for recipe in to_display:
                if search_term in data_recipes[recipe]['name']:
                    search_result.append(recipe)

            # Clear recipe_box       
            for widget in recipe_box.winfo_children():
                widget.destroy()  

            if matched_d == 'none':
                for id in search_result:
                    text_box = tkinter.Button(recipe_box, width=83, height=8, text=(id + " - " + data_recipes[id]['name'].title()), font=("Arial",17), padx=5, pady=5, bg='#f8b500', bd=5, command=partial(click_recipe, id))
                    text_box.grid(column=0, sticky='w')
                    button_box = tkinter.Frame(recipe_box, width=90, height=50, padx=5, pady=5)
                    button_box.grid(column=0, sticky='e')

                    upload_button = tkinter.Button(button_box, text="Upload photo", width=12, height=1, font=("Arial",13), bd=3, command=lambda id=id: submission_onclick(id))
                    upload_button.grid(row=0, column=0)

                    if id in data_users[user]['favorites']:
                        text = "Remove from Favorites"
                    else:
                        text = "Add to Favorites"
                    favourite_button = tkinter.Button(button_box, text=text,height=1, font=("Arial",13), bd=3)
                    favourite_button.config(command=lambda id=id, btn=favourite_button: favorite_onclick(id,btn))
                    favourite_button.grid(row=0, column=1)
            else:
                for id in search_result:
                    text_box = tkinter.Button(recipe_box, width=83, height=8, text=(id + " - " + data_recipes[id]['name'].title()), font=("Arial",17), padx=5, pady=5, bg='#f8b500', bd=5, command=partial(click_recipe, id))
                    text_box.grid(column=0, sticky='w')
                    button_box = tkinter.Frame(recipe_box, width=90, height=50, padx=5, pady=5)
                    button_box.grid(column=0, sticky='ew')
                    button_box.grid_columnconfigure(0, weight=1) 
                    button_box.grid_columnconfigure(1, weight=0)
                    button_box.grid_columnconfigure(2, weight=0)

                    matched_label_text = ", ".join(matched_d[id])
                    matched_label = tkinter.Label(button_box, text=f"Matched Ingredients: {matched_label_text}", justify='left', height=1, font=("Arial",13), anchor="w")
                    matched_label.grid(row=0, column=0, sticky='ew')
                    upload_button = tkinter.Button(button_box, text="Upload photo", width=12, height=1, font=("Arial",13), bd=3, command=lambda id=id: submission_onclick(id))
                    upload_button.grid(row=0, column=1)

                    if id in data_users[user]['favorites']:
                        text = "Remove from Favorites"
                    else:
                        text = "Add to Favorites"
                    favourite_button = tkinter.Button(button_box, text=text,height=1, font=("Arial",13), bd=3)
                    favourite_button.config(command=lambda id=id, btn=favourite_button: favorite_onclick(id,btn))
                    favourite_button.grid(row=0, column=2)

        def mode1():
            condition_preferred=True
            condition_invMatching=True
            to_display=[]
            matched_d = {}
            for recipe in data_recipes:
                pre_made = data_recipes[recipe]['ingredients']['pre_made']
                main = data_recipes[recipe]['ingredients']['main']
                cuisines = data_recipes[recipe]['cuisine']

                user_allergies = data_users[user]['users_allergies']
                notPreferred_ingredients = data_users[user]['notPreferred_ingredients']
                preferred_cuisine = data_users[user]['preferred_cuisine']
                inventory = data_users[user]['inventory']

                ingredients=[]
                ingredients.extend(main + pre_made)
                ingredients = [x['name'] for x in ingredients]

                condition_preferred=True
                condition_invMatching=False
                for user_allergy in user_allergies:
                    unwanted = []
                    unwanted.extend(notPreferred_ingredients + (data_food_allergies[user_allergy]))
                    i=0
                    while condition_preferred and i <= len(ingredients)-1:
                        if ingredients[i] in unwanted:
                            condition_preferred=False
                        i=i+1
                
                matched_l=[]
                for i in range (len(inventory)):
                    if inventory[i]["ingredient"] in ingredients:
                        matched_l.append(inventory[i]["ingredient"].title())
                        condition_invMatching=True
                if condition_preferred==True and condition_invMatching==True:
                    if cuisines in preferred_cuisine:
                        to_display.insert(0, recipe)
                    else:
                        to_display.append(recipe)
                    matched_d[recipe] = matched_l

            recipe_frame = tkinter.Canvas(page, width=10)
            recipe_frame.grid(row=1, column=0, sticky='nsew')
            scrollbar = ttk.Scrollbar(page, orient='vertical', command=recipe_frame.yview)
            scrollbar.grid(sticky='ns', row=1, column=1)
            recipe_frame.configure(yscrollcommand=scrollbar.set)
            recipe_frame.bind('<Configure>', lambda e: recipe_frame.configure(scrollregion = recipe_frame.bbox('all')))
            recipe_box = tkinter.Frame(recipe_frame, width=recipe_frame.winfo_width())
            recipe_box.pack(side='top', fill='both', expand=True)
            recipe_frame.create_window((0,0), window=recipe_box, anchor='nw')
        
            for id in to_display:
                text_box = tkinter.Button(recipe_box, width=83, height=8, text=(id + " - " + data_recipes[id]['name'].title()), font=("Arial",17), padx=5, pady=5, bg='#f8b500', bd=5, command=partial(click_recipe, id))
                text_box.grid(column=0, sticky='w')
                button_box = tkinter.Frame(recipe_box, width=90, height=50, padx=5, pady=5)
                button_box.grid(column=0, sticky='ew')
                button_box.grid_columnconfigure(0, weight=1) 
                button_box.grid_columnconfigure(1, weight=0)
                button_box.grid_columnconfigure(2, weight=0)

                matched_label_text = ", ".join(matched_d[id])
                matched_label = tkinter.Label(button_box, text=f"Matched Ingredients: {matched_label_text}", justify='left', height=1, font=("Arial",13), anchor="w")
                matched_label.grid(row=0, column=0, sticky='ew')
                upload_button = tkinter.Button(button_box, text="Upload photo", width=12, height=1, font=("Arial",13), bd=3, command=lambda id=id: submission_onclick(id))
                upload_button.grid(row=0, column=1)

                if id in data_users[user]['favorites']:
                    text = "Remove from Favorites"
                else:
                    text = "Add to Favorites"
                favourite_button = tkinter.Button(button_box, text=text,height=1, font=("Arial",13), bd=3)
                favourite_button.config(command=lambda id=id, btn=favourite_button: favorite_onclick(id,btn))
                favourite_button.grid(row=0, column=2)

            search_bar.bind('<KeyRelease>', lambda e:search(e, recipe_frame, recipe_box, to_display, matched_d))  
            recipe_box.update_idletasks()
            recipe_frame.config(scrollregion=recipe_frame.bbox('all'))

        def mode2():
            recipe_frame = tkinter.Canvas(page, width=10)
            recipe_frame.grid(row=1, column=0, sticky='nsew')
            scrollbar = ttk.Scrollbar(page, orient='vertical', command=recipe_frame.yview)
            scrollbar.grid(sticky='ns', row=1, column=1)
            recipe_frame.configure(yscrollcommand=scrollbar.set)
            recipe_frame.bind('<Configure>', lambda e: recipe_frame.configure(scrollregion = recipe_frame.bbox('all')))
            recipe_box = tkinter.Frame(recipe_frame, width=recipe_frame.winfo_width())
            recipe_box.pack(side='top', fill='both', expand=True)
            recipe_frame.create_window((0,0), window=recipe_box, anchor='nw')


            for id in data_users[user]['favorites']:
                text_box = tkinter.Button(recipe_box, width=83, height=8, text=(id + " - " + data_recipes[id]['name'].title()), font=("Arial",17), padx=5, pady=5, bg='#f8b500', bd=5, command=partial(click_recipe, id))
                text_box.grid(column=0, sticky='w')
                button_box = tkinter.Frame(recipe_box, width=90, height=50, padx=5, pady=5)
                button_box.grid(column=0, sticky='e')

                upload_button = tkinter.Button(button_box, text="Upload photo", width=12, height=1, font=("Arial",13), bd=3, command=lambda id=id: submission_onclick(id))
                upload_button.grid(row=0, column=0)

                if id in data_users[user]['favorites']:
                    text = "Remove from Favorites"
                else:
                    text = "Add to Favorites"
                favourite_button = tkinter.Button(button_box, text=text,height=1, font=("Arial",13), bd=3)
                favourite_button.config(command=lambda id=id, btn=favourite_button: favorite_onclick(id,btn))
                favourite_button.grid(row=0, column=1)

            search_bar.bind('<KeyRelease>', lambda e:search(e, recipe_frame, recipe_box, data_users[user]['favorites'],'none'))  
            recipe_box.update_idletasks()
            recipe_frame.config(scrollregion=recipe_frame.bbox('all'))

        def mode3():
            recipe_frame = tkinter.Canvas(page, width=10)
            recipe_frame.grid(row=1, column=0, sticky='nsew')
            scrollbar = ttk.Scrollbar(page, orient='vertical', command=recipe_frame.yview)
            scrollbar.grid(sticky='ns', row=1, column=1)
            recipe_frame.configure(yscrollcommand=scrollbar.set)
            recipe_frame.bind('<Configure>', lambda e: recipe_frame.configure(scrollregion = recipe_frame.bbox('all')))
            recipe_box = tkinter.Frame(recipe_frame, width=recipe_frame.winfo_width())
            recipe_box.pack(side='top', fill='both', expand=True)
            recipe_frame.create_window((0,0), window=recipe_box, anchor='nw')

            for recipe in data_recipes:
                text_box = tkinter.Button(recipe_box, width=83, height=8, text=(recipe + " - " + data_recipes[recipe]['name'].title()), font=("Arial",17), padx=5, pady=5, bg='#f8b500', bd=5, command=partial(click_recipe, recipe))
                text_box.grid(column=0, sticky='w')
                button_box = tkinter.Frame(recipe_box, width=90, height=50, padx=5, pady=5)
                button_box.grid(column=0, sticky='e')

                upload_button = tkinter.Button(button_box, text="Upload photo", width=12, height=1, font=("Arial",13), bd=3, command=lambda id=recipe: submission_onclick(id))
                upload_button.grid(row=0, column=0)

                if recipe in data_users[user]['favorites']:
                    text = "Remove from Favorites"
                else:
                    text = "Add to Favorites"
                favourite_button = tkinter.Button(button_box, text=text,height=1, font=("Arial",13), bd=3)
                favourite_button.config(command=lambda id=recipe, btn=favourite_button: favorite_onclick(id,btn))
                favourite_button.grid(row=0, column=1)

            search_bar.bind('<KeyRelease>', lambda e:search(e, recipe_frame, recipe_box, list(data_recipes.keys()),'none'))  
            recipe_box.update_idletasks()
            recipe_frame.config(scrollregion=recipe_frame.bbox('all'))
        
        # Clear previous page content
        for child in page_frame.winfo_children():
            child.destroy()

        # Create content frame
        page = tkinter.LabelFrame(page_frame, text='Home', font=(
            'Arial', 30), padx=40, pady=30)
        page.pack(fill='both', expand=True)

        page.grid_rowconfigure(0, weight=0)
        page.grid_rowconfigure(1, weight=1)
        page.grid_columnconfigure(0, weight=1)

        button_frame = tkinter.Frame(page, width=60, height=60, padx=10, pady=10)
        button_frame.grid(row=0, column=0, sticky='w')

        mode_label = tkinter.Label(button_frame, text="Display modes: ",font=("Arial",15))
        mode_label.grid(row=0, column=0)
        
        mode1_button = tkinter.Button(button_frame,text="Recommendation",font=("Arial",15), width=15, height=1, bd=3, command=click1)
        mode1_button.grid(row=0, column=1)

        mode2_button = tkinter.Button(button_frame,text="Favorites",font=("Arial",15), width=10, height=1, bd=3, command=click2)
        mode2_button.grid(row=0, column=2)

        mode3_button = tkinter.Button(button_frame,text="All",font=("Arial",15), width=10, height=1, bd=3, command=click3)
        mode3_button.grid(row=0, column=3)

        search_frame = tkinter.Frame(page, width=60, height=60, padx=10, pady=10)
        search_frame.grid(row=0, column=0, sticky='e')

        search_label = tkinter.Label(search_frame, text="Search by name here:",font=("Arial",15))
        search_label.grid(row=0, column=0, padx=10)

        search_bar = tkinter.Entry(search_frame, font=('Arial',15))   
        search_bar.insert(0, '-Search here-')
        search_bar.grid(row=0, column=1)

        messagebox.showinfo('Message', 'Click on the orange boxes to read more!')
        # Default display mode
        click1()

    def user_inventory_page():
        # Function to display inventory
        def inv_table_display(list):
            # Clear table
            inv_table.delete(*inv_table.get_children())

            # Sort ingredients with nonzero amount first then 0 amount
            list_not0 = []
            list_0 = []

            for ing_data in list:
                if ing_data['amount'] != 0:
                    list_not0.append(ing_data)
                else:
                    list_0.append(ing_data)

            sorted_list = sorted(list_not0, key= lambda x: x['ingredient']) + list_0

            # Display
            for ing_data in sorted_list:
                inv_table.insert('', 'end', values=(ing_data['ingredient'].title(), ing_data['amount'], ing_data['unit']))

        # Command for Update button
        def inv_update():
            # Prompt confirmation
            yesNo = tkinter.messagebox.askyesno("Confirmation", "Are you sure you want to update and save your inventory?")

            if yesNo:
                # Handling error if amount input is lesser than 0
                if not (int(inv_input_bar_amount.get())>=0):
                    messagebox.showerror("Error", "Amount must be at least 0.")
                    return

                # Handling error if unit input does not exist
                elif not ((inv_input_bar_unit.get() in data_units)):
                    messagebox.showerror("Error", "Unit does not exist.")
                    return

                else:
                    # Update original inventory
                    if inv_input_bar_ingredient.get().lower() in [x['ingredient'] for x in user_inventory]:
                        index = [x['ingredient'] for x in user_inventory].index(inv_input_bar_ingredient.get().lower())
                        user_inventory[index]['amount'] = int(inv_input_bar_amount.get())
                        user_inventory[index]['unit'] = inv_input_bar_unit.get()
                    else:
                        user_inventory.append({
                            'ingredient' : inv_input_bar_ingredient.get().lower(),
                            'amount': int(inv_input_bar_amount.get()),
                            'unit': inv_input_bar_unit.get()
                        })

                    # Update copied inventory
                    index = [x['ingredient'] for x in copied_user_inventory].index(inv_input_bar_ingredient.get().lower())
                    copied_user_inventory[index]['amount'] = int(inv_input_bar_amount.get())
                    copied_user_inventory[index]['unit'] = inv_input_bar_unit.get()

                    # Disable Update & Clear button
                    inv_btn_update.config(state='disabled')
                    inv_btn_clear.config(state='disabled')

                    # Clear input bars
                    inv_input_bar_ingredient.delete(0,'end')
                    inv_input_bar_amount.delete(0,'end')
                    inv_input_bar_amount.insert(0, 0)
                    inv_input_bar_unit.delete(0,'end')
                    inv_input_bar_unit.insert(0, '-') 

                    # Display
                    inv_table_display(copied_user_inventory)

                # Save file to storage
                save_data(data_accounts,'accounts.json')

                messagebox.showinfo("Success", "Inventory saved successfully!")

        # Command for Clear button
        def inv_clear():
            # Prompt confirmation
            yesNo = tkinter.messagebox.askyesno("Confirmation", "Are you sure you want to clear that amount and save your inventory?")

            if yesNo:
                # Update original inventory
                if inv_input_bar_ingredient.get().lower() in [x['ingredient'] for x in user_inventory]:
                    index = [x['ingredient'] for x in user_inventory].index(inv_input_bar_ingredient.get().lower())
                    user_inventory.pop(index)

                # Update copied inventory
                index = [x['ingredient'] for x in copied_user_inventory].index(inv_input_bar_ingredient.get().lower())
                copied_user_inventory[index]['amount'] = 0
                copied_user_inventory[index]['unit'] = '-'

                # Disable Update & Clear button
                inv_btn_update.config(state='disabled')
                inv_btn_clear.config(state='disabled')

                # Clear input bars
                inv_input_bar_ingredient.delete(0,'end')
                inv_input_bar_amount.delete(0,'end')
                inv_input_bar_amount.insert(0, 0)
                inv_input_bar_unit.delete(0,'end')
                inv_input_bar_unit.insert(0, '-') 

                # Display
                inv_table_display(copied_user_inventory)

                # Save file to storage
                save_data(data_accounts,'accounts.json')

                messagebox.showinfo("Success", "Inventory saved successfully!")

        # Command for binding inv_input_bar_ingredient (Search)
        def ing_search(event):
            # Grab what user typed
            searched_term = inv_input_bar_ingredient.get().lower()
            if searched_term == '':
                output_list = copied_user_inventory
            else:
                output_list = []
                for ing_data in copied_user_inventory:
                    if searched_term in ing_data['ingredient']:
                        output_list.append(ing_data)

            inv_table_display(output_list)

        # Command for binding inv_table
        def inv_table_onselect(event):
            # Enabling the Update & Clear button after an item is selected
            if inv_table.selection():
                inv_btn_update.config(state='normal')
                inv_btn_clear.config(state='normal')
            else:
                inv_btn_update.config(state='disabled')
                inv_btn_clear.config(state='disabled')

            # Grab selected ingredient
            selected = inv_table.focus()
            values = inv_table.item(selected, 'values')

            if selected:
                # Clear Input Bars
                inv_input_bar_ingredient.delete(0,'end')
                inv_input_bar_amount.delete(0,'end')
                inv_input_bar_unit.delete(0,'end')

                # Display into Input Bars
                inv_input_bar_ingredient.insert(0,values[0])
                inv_input_bar_amount.insert(0,values[1])
                inv_input_bar_unit.insert(0,values[2])

        # Clear previous page content
        for child in page_frame.winfo_children():
            child.destroy()

        # Create content frame
        page = tkinter.LabelFrame(page_frame, text='Inventory', font=(
            'Arial', 30), padx=40, pady=30)
        page.pack(fill='both', expand=True)

        # Input Labels
        inv_input_label_ingredient = tkinter.Label(page, text='Ingredient')
        inv_input_label_ingredient.grid(row=0, column=0)

        inv_input_label_amount = tkinter.Label(page, text='Amount')
        inv_input_label_amount.grid(row=0, column=1)

        inv_input_label_unit = tkinter.Label(page, text='Unit')
        inv_input_label_unit.grid(row=0, column=2)     

        # Input Bars
        inv_input_bar_ingredient = tkinter.Entry(page)
        inv_input_bar_ingredient.grid(row=1, column=0)

        inv_input_bar_amount = tkinter.Spinbox(page, from_=0, to='infinity')
        inv_input_bar_amount.grid(row=1, column=1)

        inv_input_bar_unit = ttk.Combobox(page, values=data_units)
        inv_input_bar_unit.current(0)  # set default value to '-'
        inv_input_bar_unit.grid(row=1, column=2)

        # Inventory (Table & Scrollbar)
        inv_table_frame = tkinter.Frame(page)
        inv_table_frame.grid(row=2, column=0, columnspan=3, padx=20, pady=10)
        inv_table_scrollbar = ttk.Scrollbar(inv_table_frame)
        inv_table_scrollbar.pack(side='right', fill='y')
        inv_table = ttk.Treeview(inv_table_frame, yscrollcommand=inv_table_scrollbar.set, columns=('ingredient', 'amount', 'unit'), show='headings')
        inv_table.pack()
        inv_table_scrollbar.config(command=inv_table.yview)
        inv_table.heading('ingredient', text='Ingredient')
        inv_table.heading('amount', text='Amount')
        inv_table.heading('unit', text='Unit')

        # Update button
        inv_btn_update = tkinter.Button(page, text='Update Inventory', command=inv_update , state='disabled', width=20) 
        inv_btn_update.grid(row=3, column=0, columnspan=3, pady=10)

        # Clear button
        inv_btn_clear = tkinter.Button(page, text='Clear Amount', state='disabled', command=inv_clear, width=20) 
        inv_btn_clear.grid(row=4, column=0, columnspan=3, pady=10)

        # Get user's inventory from storage and make a copy for table
        user_inventory = data_users[user]['inventory']
        copied_user_inventory = user_inventory[:]

        # Append ingredients that user has 0 amount to inventory for searching later
        for ingredient in data_ingredients:
            if ingredient not in [x['ingredient'] for x in user_inventory]:
                empty_ing = {
                    'ingredient' : ingredient,
                    'amount' : 0,
                    'unit' : '-'
                }
                copied_user_inventory.append(empty_ing)

        inv_table_display(copied_user_inventory)

        # Binding the input bar for checking input then search matched ingredient
        inv_input_bar_ingredient.bind("<KeyRelease>", ing_search)

        # Binding the table when an item selected
        inv_table.bind('<<TreeviewSelect>>', inv_table_onselect)

    def user_shopping_list():
        def done_button():
            yesNo = tkinter.messagebox.askyesno("Confirmation", "Are you sure you want to update your shopping list?")
            if yesNo:
                selected_items = user_shopping_list_table.curselection()
                for index in selected_items[::-1]:
                    item = user_shopping_list_table.get(index)
                    user_shopping_list.remove(item.lower())
                    user_shopping_list_table.delete(index)
                save_data(data_accounts, 'accounts.json')
                messagebox.showinfo("Message","Shopping list is updated and saved successfully.")
            
        # Clear previous page content
        for frame in page_frame.winfo_children():
            frame.destroy()
        # page content
        page = tkinter.LabelFrame(page_frame, text='Shopping List', font=(
            'Arial', 30), height=150, padx=40, pady=30)
        page.pack(side='top', fill='both', expand=True)

        user_shopping_list = data_users[user]['shoppingList']

        user_shopping_list_frame = tkinter.Frame(page)
        user_shopping_list_frame.pack(side='top', fill = 'both')

        label = tkinter.Label(user_shopping_list_frame, text='Instruction : Select what to remove then click save.', font=('Arial', 16))
        label.pack()
        user_shopping_list_scrollbar = ttk.Scrollbar(user_shopping_list_frame)
        user_shopping_list_scrollbar.pack(side='right', fill='y')
        user_shopping_list_table = tkinter.Listbox(user_shopping_list_frame, yscrollcommand=user_shopping_list_scrollbar.set, selectmode="multiple", height=28, font=('Arial', 12))
        user_shopping_list_table.pack(side='top', fill='both')
        user_shopping_list_scrollbar.config(command=user_shopping_list_table.yview)
        save_button = tkinter.Button(user_shopping_list_frame, text='Save', command=done_button, font=('Arial', 14), width=10)
        save_button.pack(side='bottom')

        for item in user_shopping_list:
            user_shopping_list_table.insert('end', item.title())

    def user_submissions_page():
        # Table binding: when any row selected, the image according to the filename will be viewed
        def submission_table_onselect(event, table):
            # Grab selected row
            selected = table.focus()
            values = table.item(selected, 'values')
            filename = values[2]

            if selected: # avoid selected is being empty
                filepath = os.path.join('submissions', filename)
                image = Image.open(filepath)
                image.show()

        # User's submissions (Table & Scrollbar)
        def submission_table(status, row):
            # The label
            table_label = tkinter.Label(page, text=f'Your {status.title()} Submissions:', font=("Arial", 12))
            table_label.grid(row=row, column=0)
            
            # The table
            table_frame = tkinter.Frame(page)
            table_frame.grid(row=row, column=1, columnspan=4, pady=30, padx=20)
            table_scrollbar = ttk.Scrollbar(table_frame)
            table_scrollbar.pack(side='right', fill='y')
            table = ttk.Treeview(table_frame, yscrollcommand=table_scrollbar.set, columns=('recipe', 'time', 'filename'), show='headings', height=6)
            table.pack()
            table_scrollbar.config(command=table.yview)
            table.heading('recipe', text='Recipe')
            table.heading('time', text='Time')
            table.heading('filename', text='Filename')

            # Inserting submissions as item into table
            for submission in submissions[status]: 
                recipe = data_recipes[submission['recipe_id']]['name'].title()
                table.insert('', 'end', values=(recipe, submission['time'], submission['filename']))

            table.bind('<<TreeviewSelect>>', lambda event: submission_table_onselect(event, table))            

        # Clear previous page content
        for child in page_frame.winfo_children():
            child.destroy()

        # Create content frame
        page = tkinter.LabelFrame(page_frame, text='Submissions', font=(
            'Arial', 30), padx=40, pady=30)
        page.pack(fill='both', expand=True)

        # User's dashboard
        user_label = tkinter.Label(page, font=("Arial", 14), text=f"{user}: {data_users[user]['username']}")
        user_label.grid(row=0, column=0)

        user_points_label = tkinter.Label(page, font=("Arial", 14), text='Your points: ')
        user_points_label.grid(row=0, column=1)

        user_points = tkinter.Label(page, font=("Arial", 14), text=data_users[user]["points"])
        user_points.grid(row=0, column=2)

        user_streak_label = tkinter.Label(page, font=("Arial", 14), text="Your streak: ")
        user_streak_label.grid(row=0, column=3)

        user_streak = tkinter.Label(page, font=("Arial", 14), text=data_users[user]["streak"])
        user_streak.grid(row=0, column=4)

        # Get user's submissions from storage
        submissions = data_users[user]['submissions']

        row = 1
        for status in submissions:
            submission_table(status, row)
            row += 1

    def user_feedback_page():
        def handle_feedback():
            star = int(star_entry.get())
            comment = comment_entry.get()
            #valid input
            if star in range(1,6):
                feedback={
                    "username":data_users[user]['username'],
                    "star":star,
                    "comment":comment,
                    "submittedtime":datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }

                # Clear the entries
                star_entry.delete(0,'end')
                comment_entry.delete(0,'end')

                # Update storage
                data_users[user]['feedbacks'].append(feedback)       
                save_data(data_accounts, 'accounts.json')     
                
                messagebox.showinfo("Message","Thanks for your feedback.")

            #invalid input
            else:
                messagebox.showerror("Error", "Invalid integer(Star).")
        
        # Clear previous page content
        for child in page_frame.winfo_children():
            child.destroy()

        # Create content frame
        page = tkinter.LabelFrame(page_frame, text='Feedback', font=(
            'Arial', 30), padx=40, pady=30)
        page.pack(fill='both', expand=True)

        instruction_label = tkinter.Label(page, text="Please give us your feedback on this program. :)", font=("Arial", 14))
        instruction_label.pack(pady=20)

        star_label = tkinter.Label(page, text="Star (1-5) :", font=("Arial", 12))
        star_label.pack()
        star_entry = tkinter.Entry(page, font=("Arial", 12))
        star_entry.pack(pady=20)

        comment_label = tkinter.Label(page, text="Comment:", font=("Arial", 12))
        comment_label.pack()
        comment_entry = tkinter.Entry(page, font=("Arial", 12))
        comment_entry.pack(pady=20)                         

        submit_btn = tkinter.Button(page, text="Submit", command=handle_feedback, font=("Arial", 12))
        submit_btn.pack()

    def user_settings_page(regEvent):
        def user_personalise_popup():
            # Command for binding when a option in preferred_cuisine_input is being selected
            def preferred_cuisine_selected(event):
                # Get selected option
                selected_value = preferred_cuisine_input.get()
                items_listbox = list(preferred_cuisine_listbox.get(0, 'end'))
                if selected_value in items_listbox:
                    # If value already exists in the listbox, remove it
                    index = items_listbox.index(selected_value)
                    preferred_cuisine_listbox.delete(index)
                else:
                    # If value does not exist in the listbox, insert it
                    preferred_cuisine_listbox.insert('end', selected_value)

            # Command for binding when a option in food_allergies_input is being selected
            def food_allergies_selected(event):
                selected_allergy = food_allergies_input.get()
                items_listbox1 = list(food_allergies_listbox1.get(0, 'end'))
                if selected_allergy in items_listbox1:
                    # If value already exists in the listbox1, remove it
                    index = items_listbox1.index(selected_allergy)
                    food_allergies_listbox1.delete(index)
                    food_allergies_listbox2.delete(0, 'end')  

                    # Refresh the ingredients in listbox2
                    for allergy in food_allergies_listbox1.get(0, 'end'):
                        foods = data_food_allergies[allergy.lower()]
                        for food in foods:
                            food_allergies_listbox2.insert('end', food.title())
                else:
                    # If value does not exist in the listbox1, insert it
                    food_allergies_listbox1.insert('end', selected_allergy)

                    # Append the new allergy's ingredients to listbox2
                    foods = data_food_allergies[selected_allergy.lower()]
                    for food in foods:
                        food_allergies_listbox2.insert('end', food.title())      

            # Command for binding notPreferred_ingredients_input for searching
            def notPreferred_ingredients_search(event):
                search_term = notPreferred_ingredients_input.get().lower()

                # Clear the results
                notPreferred_ingredients_search_results.delete(0, 'end')

                for ingredient in data_ingredients:
                    # If the search_term match any ingredient as substring
                    if search_term in ingredient.lower():
                        notPreferred_ingredients_search_results.insert('end', ingredient.title())

            # Command for binding item in notPreferred_ingredients_listbox is being selected
            def notPreferred_ingredients_listbox_onselect(event):
                # Check if notPreferred_ingredients_search_results.curselection() is not empty
                if notPreferred_ingredients_search_results.curselection():
                    selected_ingredient = notPreferred_ingredients_search_results.get(notPreferred_ingredients_search_results.curselection())

                    # If value does not exist in the notPreferred_ingredients_listbox, insert it
                    if selected_ingredient not in notPreferred_ingredients_listbox.get(0, 'end'):
                        notPreferred_ingredients_listbox.insert('end', selected_ingredient)
                    # Else, remove it
                    else:
                        notPreferred_ingredients_listbox.delete(notPreferred_ingredients_listbox.get(0, 'end').index(selected_ingredient))

            # Command for Save button
            def personalise_save():
                # Prompt confirmation
                yesNo = tkinter.messagebox.askyesno("Confirmation", "Are you sure you want to save your personalisation?")

                if yesNo:                
                    # Get the respective input, then loop each to lower the string case. Then update.
                    data_users[user]["preferred_cuisine"] = [x.lower() for x in list(preferred_cuisine_listbox.get(0, 'end'))]
                    data_users[user]["users_allergies"] = [x.lower() for x in list(food_allergies_listbox1.get(0, 'end'))]
                    data_users[user]["notPreferred_ingredients"] = [x.lower() for x in list(notPreferred_ingredients_listbox.get(0, 'end'))]
                    
                    # Save to storage
                    save_data(data_accounts,'accounts.json')

                    messagebox.showinfo("Success", "Personalisation saved successfully!")
                    personalise_window.destroy()
            # The popup window
            personalise_window = tkinter.Toplevel()
            personalise_window.title("Personalise")
            personalise_window.grab_set()

            # The big frame 
            personalise_window_frame = tkinter.Frame(personalise_window, padx=10, pady=5)
            personalise_window_frame.pack()

            # 0. Text for instruction
            personalise_window_instruction = tkinter.Label(personalise_window_frame, text='Personalise Your Recommendation.', font=16)
            personalise_window_instruction.grid(row=0, column=0, columnspan=3)

            # 1. Preferred Cuisine frame
            preferred_cuisine_frame = tkinter.LabelFrame(personalise_window_frame, text='Preferred Cuisine', padx=20, pady=5)
            preferred_cuisine_frame.grid(row=1, column=0, pady=20)

            options_preferred_cuisine = [x.title() for x in data_preferred_cuisine]
            preferred_cuisine_input = ttk.Combobox(preferred_cuisine_frame, values=options_preferred_cuisine)
            preferred_cuisine_input.grid(row=0, column=0, rowspan=2, padx=20)
        
            preferred_cuisine_listbox_label = tkinter.Label(preferred_cuisine_frame, text='Your Preferred Cuisine')
            preferred_cuisine_listbox_label.grid(row=0, column=1, padx=20)

            preferred_cuisine_listbox = tkinter.Listbox(preferred_cuisine_frame, height=3)
            preferred_cuisine_listbox.grid(row=1, column=1)

            # Display user's Preferred Cuisine from storage
            for cuisine in data_users[user]["preferred_cuisine"]:
                preferred_cuisine_listbox.insert('end', cuisine.title())

            preferred_cuisine_input.bind("<<ComboboxSelected>>", preferred_cuisine_selected)       

            # 2. Food Allergies frame
            food_allergies_frame = tkinter.LabelFrame(personalise_window_frame, text='Diet or Food Allergies', padx=20, pady=5)
            food_allergies_frame.grid(row=2, column=0, pady=20)

            options_food_allergies = [x.title() for x in list(data_food_allergies.keys())]
            food_allergies_input = ttk.Combobox(food_allergies_frame, values=options_food_allergies)
            food_allergies_input.grid(row=0, column=0, rowspan=2, padx=20)

            # Listbox for Diet or Food Allergies
            food_allergies_listbox1_label = tkinter.Label(food_allergies_frame, text='Your Diet or Food Allergies')
            food_allergies_listbox1_label.grid(row=0, column=1, padx=20)
            food_allergies_listbox1 = tkinter.Listbox(food_allergies_frame)
            food_allergies_listbox1.grid(row=1, column=1, padx=20)        

            # Listbox for related foods
            food_allergies_listbox2_label = tkinter.Label(food_allergies_frame, text='Ingredients You Cannot Eat:')
            food_allergies_listbox2_label.grid(row=0, column=2, padx=20)
            food_allergies_listbox2 = tkinter.Listbox(food_allergies_frame)
            food_allergies_listbox2.grid(row=1, column=2, padx=20)

            # Display user's Food Allergies from storage
            for allergy in data_users[user]["users_allergies"]:
                food_allergies_listbox1.insert('end', allergy.title())

                related_ing = data_food_allergies[allergy]
                for ing in related_ing:
                    food_allergies_listbox2.insert('end', ing.title())

            food_allergies_input.bind("<<ComboboxSelected>>", food_allergies_selected)
        
            # 3. Not Prefered Ingredients frame
            notPreferred_ingredients_frame = tkinter.LabelFrame(personalise_window_frame, text='Not Preferred Ingredients', padx=20, pady=5)
            notPreferred_ingredients_frame.grid(row=3, column=0, pady=10)

            notPreferred_ingredients_input = tkinter.Entry(notPreferred_ingredients_frame)
            notPreferred_ingredients_input.grid(row=0, column=0, padx=20, pady=10)
            notPreferred_ingredients_input.insert(0, '-Search here-')

            notPreferred_ingredients_listbox_label = tkinter.Label(notPreferred_ingredients_frame, text='Your Not Preferred Ingredients')
            notPreferred_ingredients_listbox_label.grid(row=0, column=1, padx=20)

            notPreferred_ingredients_listbox = tkinter.Listbox(notPreferred_ingredients_frame)
            notPreferred_ingredients_listbox.grid(row=1, column=1, padx=20)

            notPreferred_ingredients_search_results = tkinter.Listbox(notPreferred_ingredients_frame, width=50)
            notPreferred_ingredients_search_results.grid(row=1, column=0, padx=20)

            # Display user's Not Prefered Ingredients from storage
            for ing in data_users[user]["notPreferred_ingredients"]:
                notPreferred_ingredients_listbox.insert('end', ing.title())

            notPreferred_ingredients_input.bind('<KeyRelease>', notPreferred_ingredients_search)

            notPreferred_ingredients_search_results.bind('<<ListboxSelect>>', notPreferred_ingredients_listbox_onselect)
        
            # 4. Save button
            personalise_save_btn = tkinter.Button(personalise_window_frame, text='Save Changes', command=personalise_save, bg='#f8b500', fg='#23231A')
            personalise_save_btn.grid(row=4, column=0)

        def change_password_popup():
            # Function to handle the password change
            def change_password():
                # Access the variable 'counter'
                nonlocal counter

                # Get inputs
                old_pw_attempt = old_pw_input.get()
                new_pw = new_pw_input.get().strip()

                # Check if old password is correct
                if old_pw_attempt == old_pw:
                    # Check if new password is not empty
                    if new_pw:
                        messagebox.showinfo("Success", "Password changed successfully!")

                        # Update password
                        data_users[user]['password'] = new_pw

                        # Save to storage
                        save_data(data_accounts,'accounts.json')

                        # Close the window
                        change_password_window.destroy()
                    else:
                        tkinter.messagebox.showerror("Error", "Password cannot be empty!")

                else:
                    counter -= 1
                    tkinter.messagebox.showerror("Error", f"Incorrect password! {counter} attempts left.")
                    if counter == 0:
                        tkinter.messagebox.showerror("Error", "Maximum number of attempts reached!")

                        # Close the window         
                        change_password_window.destroy()  

            # The popup window
            change_password_window = tkinter.Toplevel()
            change_password_window.title("Change Password")
            change_password_window.geometry('400x300')
            change_password_window.grab_set()

            # The big frame
            change_password_window_frame = tkinter.Frame(change_password_window, padx=10, pady=5)
            change_password_window_frame.pack()

            # Get user's old password
            old_pw = data_users[user]['password']

            # Text for instruction
            personalise_window_instruction = tkinter.Label(change_password_window_frame, text='Change password.', font=16)
            personalise_window_instruction.pack(pady=10)

            # Old Password Label and Entry
            old_pw_label = tkinter.Label(change_password_window_frame, text="Enter your old password:")
            old_pw_label.pack()
            old_pw_input = tkinter.Entry(change_password_window_frame, show="*")
            old_pw_input.pack(pady=10)

            # New Password Label and Entry
            new_pw_label = tkinter.Label(change_password_window_frame, text="Enter your new password:")
            new_pw_label.pack()
            new_pw_input = tkinter.Entry(change_password_window_frame, show="*")
            new_pw_input.pack(pady=10)

            # Given 3 attempts, repeat change_password until successful or 0 attempts left
            counter = 3

            # Submit Button
            submit_button = tkinter.Button(change_password_window_frame, text="Submit", command=change_password, bg='#f8b500', fg='#23231A')
            submit_button.pack()

            change_password_window.mainloop()

        def delete_account():
            # Prompt confirmation
            yesNo = tkinter.messagebox.askyesno("Confirmation", "Are you sure you want to delete your account?")

            if yesNo:  
                # Build the submission filename pattern based on the user ID        
                filename = user + "_*"           
                path = os.path.join('submissions', filename)     

                # Get all files matching that pattern        
                files = glob.glob(path)  

                # Remove each file         
                for file in files:        
                    os.remove(file)

                # Delete account from storage then save
                data_users.pop(user)
                save_data(data_accounts, 'accounts.json')    

                # Close the window    
                window_user_page.destroy()               

                # Go to authentication
                authentication_page()

        # Check if the program still at registration state
        if regEvent == 'reg':
            user_personalise_popup()
            return

        # Clear previous page content
        for child in page_frame.winfo_children():
            child.destroy()

        # Create content frame
        page = tkinter.LabelFrame(page_frame, text='Settings', font=(
            'Arial', 30), padx=40, pady=30)
        page.pack(fill='both', expand=True)

        # Buttons
        btn_personalise = tkinter.Button(page,width=50, text="Personalise", font=("Arial", 16),command=user_personalise_popup, relief='solid')
        btn_personalise.pack(pady=50)

        btn_changePW = tkinter.Button(page,width=50, text="Change Password", font=("Arial", 16),command=change_password_popup, relief='solid')
        btn_changePW.pack(pady=50)

        btn_deleteACC = tkinter.Button(page,width=50, text="Delete Account", font=("Arial", 16),command=delete_account, relief='flat', bg='red', fg='white')
        btn_deleteACC.pack(pady=50)          
        
    def logout():
        # Prompt confirmation
        yesNo = tkinter.messagebox.askyesno("Confirmation", "Are you sure you want to logout?")

        if yesNo:
            # Close the window 
            window_user_page.destroy()  

            # Go to authentication
            authentication_page()

    # The window
    window_user_page = tkinter.Tk()
    window_user_page.state('zoomed')
    window_user_page.title('CookPal')

    # Sidebar 
    sidebar_frame = tkinter.Frame(window_user_page)
    # sidebar_frame.pack_propagate(False)
    sidebar_frame.pack(side='left', fill='y')   

    # Sidebar - Logo
    logo = Image.open("CookPal.png")
    width, height = logo.size
    logo = logo.crop((0, height//3, width, 2*height//3))
    logo = logo.resize((240, 100))
    logo = ImageTk.PhotoImage(logo)
    logo_label = tkinter.Label(sidebar_frame, image=logo)
    logo_label.grid(row=0, column=0, pady=10, sticky='ew') 

    # Sidebar - Buttons
    home_btn = tkinter.Button(sidebar_frame, text='Home', font=('Arial', 16), command=user_home_page, relief='flat')
    home_btn.grid(row=1, column=0, pady=10, sticky='ew')

    inventory_btn = tkinter.Button(sidebar_frame, text='Inventory', font=('Arial', 16), relief='flat', command=user_inventory_page)
    inventory_btn.grid(row=2, column=0, pady=10, sticky='ew')

    shoppingList_btn = tkinter.Button(sidebar_frame, text='Shopping List', font=('Arial', 16), relief='flat', command=user_shopping_list)
    shoppingList_btn.grid(row=3, column=0, pady=10, sticky='ew')

    submissions_btn = tkinter.Button(sidebar_frame, text='Submissions', font=('Arial', 16), relief='flat', command=user_submissions_page)
    submissions_btn.grid(row=4, column=0, pady=10, sticky='ew')

    feedback_btn = tkinter.Button(sidebar_frame, text='Feedback', font=('Arial', 16), relief='flat', command=user_feedback_page)
    feedback_btn.grid(row=5, column=0, pady=10, sticky='ew')

    settings_btn = tkinter.Button(sidebar_frame, text='Settings', font=('Arial', 16), command=lambda: user_settings_page('none'), relief='flat')
    settings_btn.grid(row=6, column=0, pady=10, sticky='ew')

    logout_btn = tkinter.Button(sidebar_frame, text='Logout', font=('Arial', 16), command=logout, relief='flat')
    logout_btn['background'] = '#f8b500'
    logout_btn.grid(row=7, column=0, pady=10, sticky='ew')   

    # Page
    page_frame = tkinter.Frame(window_user_page, padx=40, pady=30)
    # page_frame.pack_propagate(False)
    page_frame.pack(side='right', fill='both', expand=True)


    # if in registration, run these
    if regEvent == 'reg':
        messagebox.showinfo("Registration", "Enter some info to personalise your recommendation. Then, enter what do you have in your inventory.")
        user_settings_page('reg')
        user_inventory_page()
    else:
        # Default page
        user_home_page()

    window_user_page.mainloop()

def admin_page():
    def admin_home_page():
        # Clear previous page content
        for child in page_frame.winfo_children():
            child.destroy()

        # Create content frame
        page = tkinter.LabelFrame(page_frame, text='Home', font=(
            'Arial', 30), padx=40, pady=30)
        page.pack(fill='both', expand=True)

        page.grid_rowconfigure(0, weight=1) 
        page.grid_columnconfigure(0, weight=1)

        label = tkinter.Label(page, text=f"Welcome back, {data_admins[admin]['username']} ({admin}).", font=('Arial', 30))
        label.grid(row=0, column=0, sticky="ns")

    def admin_recipes_page():
        def search_recipes(event):
            search_term = search_bar.get().lower()
            
            # Clear the listbox    
            recipe_list.delete(0, 'end')
            
            # Check each recipe against the search term
            for recipe in data_recipes:
                recipe_name = data_recipes[recipe]['name'].lower()
                if search_term in recipe_name:
                    # If matched, add to listbox
                    recipe_list.insert('end', data_recipes[recipe]['name'].title())

        def recipe_onselect(e):
            # Check if recipe_list.curselection() is not empty
            if recipe_list.curselection():
                edit_btn.config(state='active')    
                delete_btn.config(state='active')

            else:
                edit_btn.config(state='disabled')    
                delete_btn.config(state='disabled')

        def recipe_editor(recipe_toEdit):
            # Binding functions for section Ingredients
            def search_ing(e):
                search_term = ing_search_bar.get().lower()

                # Clear the results
                ing_search_result.delete(0, 'end')

                for ingredient in data_ingredients:
                    # If the search_term match any ingredient as substring
                    if search_term in ingredient.lower():
                        ing_search_result.insert('end', ingredient.title())

            def ing_search_result_onselect(e):
                # Check if ing_search_result.curselection() is not empty
                if ing_search_result.curselection():
                    # Get selected ingredient
                    selection = ing_search_result.get(ing_search_result.curselection())
                    # Set search bar text 
                    ing_search_bar.delete(0, 'end')
                    ing_search_bar.insert(0, selection)               

            def table_onselect(e, table):
                # Get the data of the selected item
                if table.selection():
                    item = table.selection()[0]
                    values = table.item(item, 'values')
                    
                    # Replace the entries with the data
                    ing_search_bar.delete(0, 'end')
                    ing_search_bar.insert(0, values[0])  
                    ing_amount_input.delete(0)           
                    ing_amount_input.insert(0, values[1])
                    ing_unit_input.set(values[2])  

                    if table == main_ing_table:
                        ing_type_input.set('Main')
                    else:
                        ing_type_input.set('Premade')

                    # Activate remove button
                    ing_remove_btn.config(state='active')

            def ing_add_btn_command():
                # Get the inputs
                ingredient = ing_search_bar.get()
                unit = ing_unit_input.get()
                ing_type = ing_type_input.get()  
                
                # Validate inputs
                if not ingredient.strip():
                    messagebox.showerror('Error', 'Invalid ingredient.')
                    return
                
                try:
                    amount = int(ing_amount_input.get())
                except:
                    messagebox.showerror('Error', 'Invalid amount.')
                    return    
                
                if amount <= 0:
                    messagebox.showerror('Error', 'Invalid amount.')
                    return

                if ing_type == 'Main':
                    table = main_ing_table
                elif ing_type == 'Premade':
                    table = premade_ing_table
                else:
                    messagebox.showerror('Error', 'Invalid type.')
                    return
                
                # Check if any existing ingredients match  
                existing = None
                for item in table.get_children():
                    if table.item(item,'values')[0] == ingredient:
                        existing = item
                        break
                        
                if existing:
                    # Remove old
                    table.delete(existing)
                        
                # Add new ingredient       
                table.insert('', 'end',values = (ingredient, amount, unit))              

            def ing_remove_btn_command():
                # Get the selected ingredient table
                if ing_type_input.get() == 'Main':
                    table = main_ing_table
                else:
                    table = premade_ing_table
                    
                # Get the selected item from the table    
                selected = table.selection()[0]

                # Remove the item from the table    
                table.delete(selected)  
                
                # Clear the form fields
                ing_search_bar.delete(0, 'end') 
                ing_amount_input.delete(0)   
                ing_unit_input.set('')
                ing_type_input.set('')
                
                # Deactivate the remove button
                ing_remove_btn.config(state='disabled')

            # Binding functions for section Steps
            def add_step():
                step = step_input.get()

                # Check if not empty
                if not step.strip():
                    messagebox.showerror('Error', 'Invalid input.')
                    return

                steps_list.insert('end', step)
                step_input.delete(0, 'end')

            def remove_step():
                # Get selected step 
                if steps_list.curselection():  
                    selection = steps_list.get(steps_list.curselection())         
                    
                    # Delete selected step from list
                    steps_list.delete(steps_list.curselection())
                
                    # Deactivate button
                    remove_step_btn.config(state='disabled')

            def steps_list_onselect(e):
                if steps_list.curselection():
                    remove_step_btn.config(state='active')

                else:
                    remove_step_btn.config(state='disabled')

            def editor_save():    
                # Get input data      
                name = name_input.get().strip().lower()
                cuisine = cuisine_input.get().strip().lower()
                difficulty = difficulty_input.get()
                servings = servings_input.get()
                steps = [steps_list.get(i) for i in range(steps_list.size())]

                ingredients = {}
                ingredients["main"] = []
                for item in main_ing_table.get_children():
                    ingredient = {}
                    ingredient["name"] = main_ing_table.item(item, "values")[0].lower()
                    ingredient["amount"] = main_ing_table.item(item, "values")[1]
                    ingredient["unit"] = main_ing_table.item(item, "values")[2] 
                    ingredients["main"].append(ingredient)

                ingredients["pre_made"] = []
                for item in premade_ing_table.get_children():
                    ingredient = {}
                    ingredient["name"] = premade_ing_table.item(item, "values")[0].lower()
                    ingredient["amount"] = premade_ing_table.item(item, "values")[1]
                    ingredient["unit"] = premade_ing_table.item(item, "values")[2] 
                    ingredients["pre_made"].append(ingredient)

                # Validate inputs
                if not name:
                    messagebox.showerror('Error', 'Recipe name cannot be empty.')
                    return
                
                if recipe_toEdit == 'new' and name in [data_recipes[x]['name'] for x in data_recipes]:
                    messagebox.showerror('Error', 'Recipe already exist.')
                    return
                
                if difficulty not in ('Easy','Medium','Hard'):
                    messagebox.showerror('Error', 'Invalid difficulty.')
                    return

                if not ingredients['main'] and not ingredients['pre_made']:
                    messagebox.showerror('Error', 'At least 1 ingredient required.') 
                    return
                
                if not steps:
                    messagebox.showerror('Error', 'At least 1 cooking step.') 
                    return             
                
                # Check if there is new ingredient/unit/cuisine
                global data_ingredients, data_units, data_preferred_cuisine
                ingredient_list = ingredients["main"] + ingredients["pre_made"]
                for ingredient in ingredient_list:
                    if ingredient['name'] not in data_ingredients:
                        data_ingredients.append(ingredient['name'])
                    if ingredient['unit'] not in data_units:
                        data_units.append(ingredient['unit'])

                if not cuisine:
                    cuisine = '-'
                elif cuisine not in data_preferred_cuisine:
                    data_preferred_cuisine.append(cuisine)

                # Get recipe_id
                if recipe_toEdit == 'new':
                    id_nums = [int(id[1:]) for id in list(data_recipes)]
                    last_id = max(id_nums)
                    recipe_id = 'R' + str(last_id+1)

                else:
                    for recipe in data_recipes:
                        if recipe == recipe_toEdit:
                            recipe_id = recipe
                            break

                # Update to storage
                data_recipes[recipe_id] = {
                    'name': name,
                    'cuisine': cuisine,
                    'difficulty': difficulty,
                    'servings': servings,
                    'ingredients': ingredients,
                    'steps': steps    
                }
                
                # Save to storage
                save_data(data_recipes, 'recipes.json')
                save_data(data_ingredientsNunits, 'ingredients_units.json')
                save_data(data_personalise_options, 'personalise_options.json')

                messagebox.showinfo('Message', 'Recipe saved sucessfully.')
                
                editor_window.destroy()
                admin_recipes_page()

            editor_window = tkinter.Toplevel()
            editor_window.title("Recipe Editor Form")
            editor_window.grab_set()
            
            title_label = tkinter.Label(editor_window, text='Recipe Editor', font=('Arial', 18))
            title_label.pack()

            # Create frames
            form_frame = tkinter.Frame(editor_window)
            form_frame.pack(padx=20 ,pady=20)
            
            # Name input
            name_label = tkinter.Label(form_frame, text="Name: ")
            name_label.grid(row=0, column=0, sticky="w")
            name_input = tkinter.Entry(form_frame)
            name_input.grid(row=0, column=1, padx=(0,10))
            
            # Cuisine input
            cuisine_label = tkinter.Label(form_frame, text="Cuisine: ")
            cuisine_label.grid(row=0, column=2, sticky="w")
            cuisine_input = ttk.Combobox(form_frame, values=data_preferred_cuisine) 
            cuisine_input.grid(row=0, column=3, padx=(0,10))

            # Difficulty input
            difficulty_label = tkinter.Label(form_frame, text="Difficulty: ")
            difficulty_label.grid(row=0, column=4, sticky="w")
            difficulty_input = ttk.Combobox(form_frame, values=('Easy','Medium','Hard')) 
            difficulty_input.grid(row=0, column=5, padx=(0,10))
            
            # Servings input
            servings_label = tkinter.Label(form_frame, text="Servings: ")
            servings_label.grid(row=0, column=6, sticky="w")
            servings_input = tkinter.Entry(form_frame)
            servings_input.grid(row=0, column=7, padx=(0,10))

            # Ingredients 
            # Input form
            ing_frame = tkinter.LabelFrame(form_frame, text='Ingredients', padx=10, pady=10)
            ing_frame.grid(row=1, column=0, columnspan=8, pady=20)

            ing_form_frame = tkinter.Frame(ing_frame)
            ing_form_frame.grid(row=0, column=0, rowspan=2)

            # Search bar and search results
            ing_search_bar = tkinter.Entry(ing_form_frame)
            ing_search_bar.grid(row=0, column=0, columnspan=2)
            ing_search_bar.insert(0, '-Search here-')
            ing_search_bar.bind('<KeyRelease>', search_ing)

            ing_search_result = tkinter.Listbox(ing_form_frame, width=30, height=6)
            ing_search_result.grid(row=1, column=0, columnspan=2, pady=(0,10))
            ing_search_result.bind('<<ListboxSelect>>', ing_search_result_onselect)

            ing_amount_label = tkinter.Label(ing_form_frame, text='Amount:')
            ing_amount_label.grid(row=2, column=0, pady=(0,10))
            ing_amount_input = ttk.Spinbox(ing_form_frame, from_=1, to='infinity')
            ing_amount_input.grid(row=2, column=1, pady=(0,10))

            ing_unit_label = tkinter.Label(ing_form_frame, text='Unit:')
            ing_unit_label.grid(row=3, column=0, pady=(0,10))
            ing_unit_input = ttk.Combobox(ing_form_frame, values=data_units)
            ing_unit_input.grid(row=3, column=1, pady=(0,10))

            ing_type_label = tkinter.Label(ing_form_frame, text='Type:')
            ing_type_label.grid(row=4, column=0, pady=(0,10))
            ing_type_input = ttk.Combobox(ing_form_frame, values=('Main', 'Premade'))
            ing_type_input.grid(row=4, column=1, pady=(0,10))

            ing_add_btn = tkinter.Button(ing_form_frame, text='Add to list', width=14 ,command=ing_add_btn_command)
            ing_add_btn.grid(row=5, column=0)

            ing_remove_btn = tkinter.Button(ing_form_frame, text='Remove from list', width=14 ,command=ing_remove_btn_command)
            ing_remove_btn.grid(row=5, column=1)
            ing_remove_btn.config(state='disabled')

            # Table (Main ingredients)
            main_ing_label = tkinter.Label(ing_frame, text='Main Ingredients')
            main_ing_label.grid(row=0, column=1, padx=20)
            main_ing_table = ttk.Treeview(ing_frame, columns=('ingredient', 'amount', 'unit'), show='headings')
            main_ing_table.grid(row=1, column=1, padx=20)
            main_ing_table.heading('ingredient', text='Ingredient')
            main_ing_table.heading('amount', text='Amount')
            main_ing_table.heading('unit', text='Unit')
            main_ing_table.column('ingredient', width=200)  
            main_ing_table.column('amount', width=60)     
            main_ing_table.column('unit', width=60)
            main_ing_table.bind('<<TreeviewSelect>>', lambda e: table_onselect(e, main_ing_table))

            # Table (Premade ingredients)
            premade_ing_label = tkinter.Label(ing_frame, text='Premade Ingredients')
            premade_ing_label.grid(row=0, column=2)
            premade_ing_table = ttk.Treeview(ing_frame, columns=('ingredient', 'amount', 'unit'), show='headings')
            premade_ing_table.grid(row=1, column=2)
            premade_ing_table.heading('ingredient', text='Ingredient')
            premade_ing_table.heading('amount', text='Amount')
            premade_ing_table.heading('unit', text='Unit')
            premade_ing_table.column('ingredient', width=200)  
            premade_ing_table.column('amount', width=60)     
            premade_ing_table.column('unit', width=60)
            premade_ing_table.bind('<<TreeviewSelect>>', lambda e: table_onselect(e, premade_ing_table))
            
            # Steps
            steps_frame = tkinter.LabelFrame(form_frame, text='Steps', padx=10, pady=10)
            steps_frame.grid(row=2, column=0, columnspan=8, pady=20)

            # Steps input
            step_input = tkinter.Entry(steps_frame, width=100)
            step_input.grid(row=0, column=0, padx=20 )
            add_step_btn = tkinter.Button(steps_frame, text='Add Step', command=add_step)
            add_step_btn.grid(row=0, column=1)
            remove_step_btn = tkinter.Button(steps_frame, text='Remove Step', command=remove_step)
            remove_step_btn.grid(row=0, column=2)
            remove_step_btn.config(state='disabled')

            # Steps list
            steps_list = tkinter.Listbox(steps_frame, width=160)
            steps_list.grid(row=1, column=0, columnspan=3, pady=10)
            steps_list.bind('<<ListboxSelect>>', steps_list_onselect)

            # Horizontal Scrollbar    
            steps_list_scrollbar = ttk.Scrollbar(steps_frame, orient='horizontal', command=steps_list.xview)
            steps_list_scrollbar.grid(row=2, column=0, columnspan=3, sticky='ew')
            steps_list.configure(xscrollcommand=steps_list_scrollbar.set)

            # Save button 
            save_btn = tkinter.Button(form_frame, text="Save", command=editor_save, width=20)  
            save_btn.grid(row=3, column=0, columnspan=8)

            # If this is not new recipe_toEdit, display the data on the entries
            if recipe_toEdit != 'new':
                # Get the data
                recipe_name = data_recipes[recipe_toEdit]['name']
                recipe_cuisine = data_recipes[recipe_toEdit]['cuisine']
                recipe_difficulty = data_recipes[recipe_toEdit]['difficulty']
                recipe_servings = data_recipes[recipe_toEdit]['servings']
                recipe_steps = data_recipes[recipe_toEdit]['steps']
                recipe_main_ing = data_recipes[recipe_toEdit]['ingredients']['main']
                try:
                    recipe_premade_ing = data_recipes[recipe_toEdit]['ingredients']['pre_made']
                except:
                    recipe_premade_ing = []

                # Insert the data of recipe to the entries 
                name_input.insert(0, recipe_name.title())
                cuisine_input.set(recipe_cuisine.title())
                difficulty_input.set(recipe_difficulty)
                servings_input.insert(0, recipe_servings)

                for ingredient in recipe_main_ing:
                    main_ing_table.insert('', 'end',values = (ingredient['name'].title(), ingredient['amount'], ingredient['unit']))  
                
                for ingredient in recipe_premade_ing:
                    premade_ing_table.insert('', 'end',values = (ingredient['name'].title(), ingredient['amount'], ingredient['unit']))  

                for step in recipe_steps:
                    steps_list.insert('end', step)

        def add_recipe():
            recipe_editor('new')

        def edit_recipe():
            selected_recipe = recipe_list.get(recipe_list.curselection())
            # Remove recipe from storage
            for recipe in data_recipes:
                if data_recipes[recipe]['name'] == selected_recipe.lower():
                    recipe_editor(recipe)
                    break

        def delete_recipe():
            selected_recipe = recipe_list.get(recipe_list.curselection())
            yesNo = tkinter.messagebox.askyesno("Confirmation", f"Are you sure you want to delete {selected_recipe}?")
            
            if yesNo:
                # Remove recipe from storage
                for recipe in data_recipes:
                    if data_recipes[recipe]['name'] == selected_recipe.lower():
                        data_recipes.pop(recipe)
                        break
                
                # Save to storage file
                save_data(data_recipes, 'recipes.json')
                
                # Clear listbox
                recipe_list.delete(0, 'end')     
                
                # Refresh listbox           
                for recipe in data_recipes:            
                    recipe_list.insert('end', data_recipes[recipe]['name'].title())
                
                messagebox.showinfo("Success", f"{selected_recipe} has removed successfully.")

        # Clear previous page content     
        for child in page_frame.winfo_children():
            child.destroy()
            
        # Create content frame      
        page = tkinter.LabelFrame(page_frame, text='Recipes', font=(
            'Arial', 30), padx=40, pady=30) 
        page.pack(fill='both', expand=True)      
        
        # Search bar
        search_bar = tkinter.Entry(page, font=('Arial',14))
        search_bar.pack(pady=10)
        search_bar.insert(0, '-Search here-')
        search_bar.bind('<KeyRelease>', search_recipes)
        
        # Listbox 
        recipe_list = tkinter.Listbox(page, font=('Arial',14), height=20)   
        recipe_list.pack(pady=10, fill='x')
        recipe_list.bind('<<ListboxSelect>>', recipe_onselect)
        
        # Load recipes into listbox      
        for recipe in data_recipes:      
            recipe_list.insert('end', data_recipes[recipe]['name'].title())
            
        # Buttons      
        btn_frame = tkinter.Frame(page)
        btn_frame.pack()

        add_btn = tkinter.Button(btn_frame, text='Add New Recipe', font=('Arial', 12), command=add_recipe)      
        add_btn.grid(padx=10, row=0, column=0)   

        # Initially disabled buttons until an item in listbox is selected
        edit_btn = tkinter.Button(btn_frame, text='Edit Recipe', font=('Arial', 12), command=edit_recipe)
        edit_btn.grid(padx=10, row=0, column=1)   
        edit_btn.config(state='disabled')

        delete_btn = tkinter.Button(btn_frame, text='Delete Recipe', font=('Arial', 12), command=delete_recipe)
        delete_btn.grid(padx=10, row=0, column=2)   
        delete_btn.config(state='disabled')

    def admin_submissions_page():
        def on_select(event):
            selected_item = treeview.focus()
            if selected_item:
                values = treeview.item(selected_item, "values")
                recipe_id, time, filename, user_id = values

                # Enable the approve and reject buttons
                approve_button.config(state=tkinter.NORMAL)
                reject_button.config(state=tkinter.NORMAL)

                # Open image
                filepath = os.path.join('submissions', filename)
                image = Image.open(filepath)
                image.show()

        def process_points(user_id, recipe_id):
            # Get the difficulty level from recipes.json
            difficulty = data_recipes[recipe_id]['difficulty']

            # Check the difficulty level and update user's points accordingly
            if difficulty == 'Easy':
                data_users[user_id]['points'] += 1
            elif difficulty == 'Medium':
                data_users[user_id]['points'] += 2
            elif difficulty == 'Hard':
                data_users[user_id]['points'] += 3

            # Update the accounts.json file
            save_data(data_accounts, 'accounts.json')

        def approve():
            selected_item = treeview.focus()
            if selected_item:
                values = treeview.item(selected_item, "values")
                recipe_id, time, filename, user_id = values

                # Move the selected submission to the approved category
                if selected_item in pending_submissions:
                    pending_submissions.remove(selected_item)
                    approved_submissions.append(selected_item)
                    data_users[user_id]['submissions']['approved'].append({
                        'recipe_id': recipe_id,
                        'time': time,
                        'filename': filename
                    })
                    # Delete the submission from the pending category
                    data_users[user_id]['submissions']['pending'] = [
                        sub for sub in data_users[user_id]['submissions']['pending'] if
                        sub['recipe_id'] != recipe_id
                    ]
                    
                # Check if the same recipe achieved a multiple of 5 after new approval
                count = 0
                for submission in data_users[user_id]['submissions']['approved']:
                    if submission['recipe_id'] == recipe_id:
                        count += 1
                if count % 5 == 0:
                    process_points(user_id, recipe_id)

                # Update the Treeview
                treeview.delete(selected_item)

                # Disable the approve and reject buttons
                approve_button.config(state=tkinter.DISABLED)
                reject_button.config(state=tkinter.DISABLED)

                # Save the updated data to the accounts.json file
                save_data(data_accounts, 'accounts.json')

        def reject():
            selected_item = treeview.focus()
            if selected_item:
                values = treeview.item(selected_item, "values")
                recipe_id, time, filename, user_id = values

                # Move the selected submission to the rejected category
                if selected_item in pending_submissions:
                    pending_submissions.remove(selected_item)
                    rejected_submissions.append(selected_item)
                    data_users[user_id]['submissions']['rejected'].append({
                        'recipe_id': recipe_id,
                        'time': time,
                        'filename': filename
                    })
                    # Delete the submission from the pending category
                    data_users[user_id]['submissions']['pending'] = [
                        sub for sub in data_users[user_id]['submissions']['pending'] if
                        sub['recipe_id'] != recipe_id
                    ]

                # Update the Treeview
                treeview.delete(selected_item)

                # Disable the approve and reject buttons
                approve_button.config(state=tkinter.DISABLED)
                reject_button.config(state=tkinter.DISABLED)

                # Save the updated data to the accounts.json file
                save_data(data_accounts, 'accounts.json')

        # Clear previous page content
        for child in page_frame.winfo_children():
            child.destroy()

        # Create content frame
        page = tkinter.LabelFrame(page_frame, text='Submissions', font=(
            'Arial', 30), padx=40, pady=30)
        page.pack(fill='both', expand=True)

        # Create the Treeview
        treeview = ttk.Treeview(page)
        treeview["columns"] = ("recipe_id", "time", "filename", "user_id")
        treeview.column("#0", width=0, stretch=tkinter.NO)
        treeview.column("recipe_id", width=100, anchor=tkinter.CENTER)
        treeview.column("time", width=150, anchor=tkinter.CENTER)
        treeview.column("filename", width=150, anchor=tkinter.CENTER)
        treeview.column("user_id", width=100, anchor=tkinter.CENTER)

        treeview.heading("#0", text="", anchor=tkinter.CENTER)
        treeview.heading("recipe_id", text="Recipe ID", anchor=tkinter.CENTER)
        treeview.heading("time", text="Time", anchor=tkinter.CENTER)
        treeview.heading("filename", text="Filename", anchor=tkinter.CENTER)
        treeview.heading("user_id", text="User ID", anchor=tkinter.CENTER)
        treeview.pack(padx=10, pady=10)
       
        # Bind the Treeview selection event
        treeview.bind("<<TreeviewSelect>>", on_select)

        # Create buttons
        approve_button = ttk.Button(page, text="Approve", command=approve, state=tkinter.DISABLED)
        approve_button.pack(pady=5)

        reject_button = ttk.Button(page, text="Reject", command=reject, state=tkinter.DISABLED)
        reject_button.pack(pady=5)

        # Lists to store approved and rejected submissions
        approved_submissions = []
        rejected_submissions = []

        # Populate the Treeview with pending submissions from all users
        pending_submissions = []
        for user_id, user_data in data_users.items():
            for submission in user_data['submissions']['pending']:
                recipe_id = submission['recipe_id']
                time = submission['time']
                filename = submission['filename']
                item = treeview.insert("", tkinter.END, values=(recipe_id, time, filename, user_id))
                pending_submissions.append(item)

    def admin_feedbacks_page():
        # Clear previous page content
        for child in page_frame.winfo_children():
            child.destroy()

        # Create content frame
        page = tkinter.LabelFrame(page_frame, text='Feedbacks', font=(
            'Arial', 30), padx=40, pady=30)
        page.pack(fill='both', expand=True)

        # Create a table to display the feedback data
        table = ttk.Treeview(page, columns=("Username", "Star", "Comment", "Submitted Time"))
        table.heading("#0", text="UID")
        table.heading("Username", text="Username")
        table.heading("Star", text="Star")
        table.heading("Comment", text="Comment")
        table.heading("Submitted Time", text="Submitted Time")
        table.pack()

        # Insert user feedback data into the table
        for user in data_users:
            userinfo = data_users[user]
            username = userinfo.get("username")
            feedback = userinfo.get("feedbacks")
            for user_feedback in feedback:
                star = user_feedback.get("star")
                comment = user_feedback.get("comment")
                submitted_time = user_feedback.get("submittedtime")
                table.insert("", "end", text=user, values=( username, star, comment, submitted_time))

    def admin_settings_page():       
        def change_password_popup():
            # Function to handle the password change
            def change_password():
                # Access the variable 'counter'
                nonlocal counter

                # Get inputs
                old_pw_attempt = old_pw_input.get()
                new_pw = new_pw_input.get().strip()

                # Check if old password is correct
                if old_pw_attempt == old_pw:
                    # Check if new password is not empty
                    if new_pw:
                        messagebox.showinfo("Success", "Password changed successfully!")

                        # Update password
                        data_admins[admin]['password'] = new_pw

                        # Save to storage
                        save_data(data_accounts,'accounts.json')

                        # Close the window
                        change_password_window.destroy()
                    else:
                        tkinter.messagebox.showerror("Error", "Password cannot be empty!")

                else:
                    counter -= 1
                    tkinter.messagebox.showerror("Error", f"Incorrect password! {counter} attempts left.")
                    if counter == 0:
                        tkinter.messagebox.showerror("Error", "Maximum number of attempts reached!")

                        # Close the window         
                        change_password_window.destroy()  

            # The popup window
            change_password_window = tkinter.Toplevel()
            change_password_window.title("Change Password")
            change_password_window.geometry('400x300')
            change_password_window.grab_set()

            # The big frame
            change_password_window_frame = tkinter.Frame(change_password_window, padx=10, pady=5)
            change_password_window_frame.pack()

            # Get user's old password
            old_pw = data_admins[admin]['password']

            # Text for instruction
            personalise_window_instruction = tkinter.Label(change_password_window_frame, text='Change password.', font=16)
            personalise_window_instruction.pack(pady=10)

            # Old Password Label and Entry
            old_pw_label = tkinter.Label(change_password_window_frame, text="Enter your old password:")
            old_pw_label.pack()
            old_pw_input = tkinter.Entry(change_password_window_frame, show="*")
            old_pw_input.pack(pady=10)

            # New Password Label and Entry
            new_pw_label = tkinter.Label(change_password_window_frame, text="Enter your new password:")
            new_pw_label.pack()
            new_pw_input = tkinter.Entry(change_password_window_frame, show="*")
            new_pw_input.pack(pady=10)

            # Given 3 attempts, repeat change_password until successful or 0 attempts left
            counter = 3

            # Submit Button
            submit_button = tkinter.Button(change_password_window_frame, text="Submit", command=change_password, bg='#f8b500', fg='#23231A')
            submit_button.pack()

            change_password_window.mainloop()

        def delete_account():
            # Prompt confirmation
            yesNo = tkinter.messagebox.askyesno("Confirmation", "Are you sure you want to delete your account?")

            if yesNo:
                # Delete account
                data_admins.pop(admin)

                # Save to storage
                save_data(data_accounts, 'accounts.json')

                # Close the window
                window_admin_page.destroy()   

                # Go to authentication
                authentication_page()

        # Clear previous page content
        for child in page_frame.winfo_children():
            child.destroy()

        # Create content frame
        page = tkinter.LabelFrame(page_frame, text='Settings', font=(
            'Arial', 30), padx=40, pady=30)
        page.pack(fill='both', expand=True)

        # Buttons
        btn_changePW = tkinter.Button(page,width=50, text="Change Password", font=("Arial", 16),command=change_password_popup, relief='solid')
        btn_changePW.pack(pady=50)

        btn_deleteACC = tkinter.Button(page,width=50, text="Delete Account", font=("Arial", 16),command=delete_account, relief='flat', bg='red', fg='white')
        btn_deleteACC.pack(pady=50)          

    def logout():
        # Prompt confirmation
        yesNo = tkinter.messagebox.askyesno("Confirmation", "Are you sure you want to logout?")

        if yesNo:
            # Close the window 
            window_admin_page.destroy()  

            # Go to authentication
            authentication_page()

    # The window
    window_admin_page = tkinter.Tk()
    window_admin_page.state('zoomed')
    window_admin_page.title('CookPal')

    # Sidebar 
    sidebar_frame = tkinter.Frame(window_admin_page)
    # sidebar_frame.pack_propagate(False)
    sidebar_frame.pack(side='left', fill='y')   

    # Sidebar - Logo
    logo = Image.open("CookPal.png")
    width, height = logo.size
    logo = logo.crop((0, height//3, width, 2*height//3))
    logo = logo.resize((240, 100))
    logo = ImageTk.PhotoImage(logo)
    logo_label = tkinter.Label(sidebar_frame, image=logo)
    logo_label.grid(row=0, column=0, pady=10, sticky='ew') 

    # Sidebar - Buttons
    home_btn = tkinter.Button(sidebar_frame, text='Home', font=('Arial', 16), command=admin_home_page, relief='flat')
    home_btn.grid(row=1, column=0, pady=10, sticky='ew')

    recipes_btn = tkinter.Button(sidebar_frame, text='Recipes', font=('Arial', 16), relief='flat', command=admin_recipes_page)
    recipes_btn.grid(row=2, column=0, pady=10, sticky='ew')

    submissions_btn = tkinter.Button(sidebar_frame, text='Submissions', font=('Arial', 16), relief='flat', command=admin_submissions_page)
    submissions_btn.grid(row=3, column=0, pady=10, sticky='ew')

    feedbacks_btn = tkinter.Button(sidebar_frame, text='Feedback', font=('Arial', 16), relief='flat', command=admin_feedbacks_page)
    feedbacks_btn.grid(row=4, column=0, pady=10, sticky='ew')

    settings_btn = tkinter.Button(sidebar_frame, text='Settings', font=('Arial', 16), relief='flat', command=admin_settings_page)
    settings_btn.grid(row=5, column=0, pady=10, sticky='ew')

    logout_btn = tkinter.Button(sidebar_frame, text='Logout', font=('Arial', 16), command=logout, relief='flat')
    logout_btn['background'] = '#f8b500'
    logout_btn.grid(row=6, column=0, pady=10, sticky='ew')   

    # Page
    page_frame = tkinter.Frame(window_admin_page, padx=40, pady=30)
    # page_frame.pack_propagate(False)
    page_frame.pack(side='right', fill='both', expand=True)

    # Default page
    admin_home_page()

    window_admin_page.mainloop()

def login(username, password):
    if role == 'user':
        for id, user_data in data_users.items():
            if user_data["username"] == username:
                if user_data["password"] == password:
                    messagebox.showinfo("Login", "Login successful!")
                    global user
                    user = id
                    window_authentication.destroy()
                    user_page('none')
                    return
                else:
                    messagebox.showerror("Login Error", "Invalid password!")
                    return
        messagebox.showerror("Login Error", "Invalid username!")
            
    else:
        for id, user_data in data_admins.items():
            if user_data["username"] == username:
                if user_data["password"] == password:
                    messagebox.showinfo("Login", "Login successful!")
                    global admin
                    admin = id
                    window_authentication.destroy()
                    admin_page()
                    return
                else:
                    messagebox.showerror("Login Error", "Invalid password!")
                    return
        messagebox.showerror("Login Error", "Invalid username!")

def generate_id():
    if role == 'user':
        if not data_users:
            return 'UID1'
        else:
            id_nums = [int(id[3:]) for id in list(data_users)]
            last_id = max(id_nums)
            new_id = 'UID' + str(last_id+1)
            return new_id
    else:
        if not data_admins:
            return 'AID1'
        else:
            id_nums = [int(id[3:]) for id in list(data_admins)]
            last_id = max(id_nums)
            new_id = 'AID' + str(last_id+1)
            return new_id

def register(key, username, password):
    if not username or not password:
        messagebox.showerror("Registration Error", "Username or password cannot be empty! Please enter another username.")
        return  
    
    if role == 'user':
        for id, user_data in data_users.items():
            if username == user_data['username']:
                messagebox.showerror("Registration Error", "Username already taken! Please enter another username.")
                return 
            
        user_data = {
            'username': username,
            'password': password,
            'preferred_cuisine': [],
            'users_allergies': [],
            'notPreferred_ingredients': [],
            'inventory': [],
            'shoppingList': [],
            'submissions': {
                'pending' : [],
                'approved' : [],
                'rejected' : []
            },
            'feedbacks': [],
            'points': 0,
            'streak': 0,
            "favorites" : []
        }

        global user
        user = generate_id()
        data_users[user] = user_data
        save_data(data_accounts, 'accounts.json')
        messagebox.showinfo("Registration", "Registration successful!")
        window_authentication.destroy()

        user_page('reg')

    else:
        if key == data_admins['AID1']['password']:
            for id, user_data in data_admins.items():
                if username == user_data['username']:
                    messagebox.showerror("Registration Error", "Username already taken! Please enter another username.")
                    return  
                
            user_data = {
                'username': username,
                'password': password            
            }       
            global admin
            admin = generate_id()
            data_admins[generate_id()] = user_data
            save_data(data_accounts, 'accounts.json')
            messagebox.showinfo("Registration", "Registration successful!")  
            window_authentication.destroy()

            admin_page()
        else:
            messagebox.showerror("Registration Error", "You enter the wrong KEY! You are not allowed to register an admin account.")

def login_page():
    window_login = tkinter.Toplevel()
    window_login.title("CookPal - Login")
    window_login.geometry("300x250")
    window_login.grab_set()

    username_label = tkinter.Label(window_login, text="Username:")
    username_label.pack()
    username_entry = tkinter.Entry(window_login)
    username_entry.pack()

    password_label = tkinter.Label(window_login, text="Password:")
    password_label.pack()
    password_entry = tkinter.Entry(window_login, show="*")
    password_entry.pack()

    login_button = tkinter.Button(window_login, text="Login", command=lambda: login(username_entry.get(), password_entry.get()))
    login_button.pack()

    window_login.mainloop()

def register_page():
    window_register = tkinter.Toplevel()
    window_register.title("CookPal - Register")
    window_register.geometry("300x250")
    window_register.grab_set()

    username_label = tkinter.Label(window_register, text="Username:")
    username_label.pack()
    username_entry = tkinter.Entry(window_register)
    username_entry.pack()

    password_label = tkinter.Label(window_register, text="Password:")
    password_label.pack()
    password_entry = tkinter.Entry(window_register, show="*")
    password_entry.pack()

    if role == 'user':
        register_button = tkinter.Button(window_register, text="Register", command=lambda: register('none', username_entry.get().strip(), password_entry.get().strip()))
        register_button.pack()
    else:
        key_label = tkinter.Label(window_register, text="KEY:")
        key_label.pack()
        key_entry = tkinter.Entry(window_register, show="*")
        key_entry.pack()        
        register_button = tkinter.Button(window_register, text="Register", command=lambda: register(key_entry.get(), username_entry.get().strip(), password_entry.get().strip()))
        register_button.pack()

    window_register.mainloop()

def authentication_page():
    def choose_action(r):
        global role
        role = r

        for widget in btn_frame.winfo_children():
            widget.destroy()

        btn_register = tkinter.Button(btn_frame, text='Register', font=("Arial, 20"), width=25, relief='solid', command=register_page)
        btn_register.pack(pady=(0,30))
        btn_login = tkinter.Button(btn_frame, text='Login', font=("Arial, 20"), width=25, relief='solid', command=login_page)
        btn_login.pack(pady=(0,30))
        btn_back = tkinter.Button(btn_frame, text='Back', font=("Arial, 20"), width=25, relief='solid', command=choose_role)
        btn_back.pack()

    def choose_role():
        for widget in btn_frame.winfo_children():
            widget.destroy()

        btn_user = tkinter.Button(btn_frame, text='User', font=("Arial, 20"), width=25, relief='solid', command= lambda: choose_action('user'))
        btn_user.pack(pady=(0,30))
        btn_admin = tkinter.Button(btn_frame, text='Admin', font=("Arial, 20"), width=25, relief='solid', command= lambda: choose_action('admin'))
        btn_admin.pack()

    global window_authentication
    window_authentication = tkinter.Tk()
    window_authentication.state('zoomed')
    window_authentication.title('CookPal')

    logo = Image.open("CookPal.png")
    logo = ImageTk.PhotoImage(logo)
    logo_label = tkinter.Label(window_authentication, image=logo)
    logo_label.pack()
    
    btn_frame = tkinter.Frame(window_authentication)
    btn_frame.pack()
    choose_role()
        
    window_authentication.mainloop()

data_personalise_options = load_data("personalise_options.json")
data_food_allergies = data_personalise_options['food_allergies']
data_preferred_cuisine = data_personalise_options['preferred_cuisine']

data_ingredientsNunits = load_data("ingredients_units.json")
data_ingredients = data_ingredientsNunits['ingredients']
data_units = data_ingredientsNunits['units']

data_recipes = load_data("recipes.json")

data_accounts = load_data("accounts.json")
data_users = data_accounts["users"]
data_admins = data_accounts["admins"]

authentication_page()
